<?php 
    $X00x0 = "localhost";
    $X00x1 = "root";
    $X00x3 = "daviD365R$";
    $X00x4 = "picel";
    $link = new mysqli($X00x0, $X00x1, $X00x3,$X00x4);
    $link->set_charset('utf8');
?>


