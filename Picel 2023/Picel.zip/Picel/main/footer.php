<footer>
    <div class="d-flex flex-column flex-md-row text-center justify-content-between p-lg-2 bg-picel align-items-center">
        <div class="text-white mb-3 mb-md-0 ps-4">
            Copyright 2023 © Programa Institucional Cultural de Experiencias Literarias
        </div>
        <div>
            <img src="../imgs/logotecnm.png" class="img-fluid" alt="PICEL" width="125">
        </div>         
    </div>
</footer>
 