    <nav class="navbar navbar-expand-lg navbar-light bg-picel">
      <div class="container-fluid">
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div>
          <img src="../imgs/logorecortado.png" class="img-fluid" alt="PICEL" width="55">
        </div>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav me-auto mb-2 mb-lg-0" style="margin: auto;">
            <li class="nav-item">
              <a class="nav-link active" aria-current="page" href="index.php">Inicio</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="../system/exit-main.php">Cerrar Sesión</a>
            </li>
          </ul>
        </div>
        <div>
          <img src="../imgs/logoitsur.png" class="img-fluid" alt="PICEL" width="55">
        </div>
      </div>
    </nav>